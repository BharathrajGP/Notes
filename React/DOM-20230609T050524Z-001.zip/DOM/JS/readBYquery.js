
function sample()
{
    var head = document.querySelector("#head");
    console.log( head );

    var tag = document.querySelector(".cls")
    console.log( tag );

    var tags = document.querySelectorAll(".cls")
    console.log( tags );

    var list =  document.querySelector("li");
    console.log(list);

    var lists =  document.querySelectorAll("li");
    console.log(lists);

}