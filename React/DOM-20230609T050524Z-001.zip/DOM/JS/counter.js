function increase()
{
    let head = document.getElementById("head1");
    // head.innerText++;
    head.innerText = Number(head.innerText) + 1;
}

function decrease()
{
    let head = document.getElementById("head1");
    // head.innerText--;
    head.innerText = Number(head.innerText) - 1;
}