const Addmovie = () => {
    return ( 
        <div>
            <h1>Add new Movie</h1>
            <form>
                <input type="text" placeholder="Movie name" />
                <input type="text" placeholder="hero name" />

                <input type="submit" value="add" />

            </form>
        </div>
     );
}
 
export default Addmovie;