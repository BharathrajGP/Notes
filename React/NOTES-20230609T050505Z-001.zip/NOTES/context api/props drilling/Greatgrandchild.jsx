const Greatgrandchild = ({count}) => {
    
    console.log("Greatgrandchild rendered");

    return ( 
        <div>
            <h1>Greatgrandchild COMP</h1>
            <h1>COUNT : {count}</h1>
        </div>
     );
}
 
export default Greatgrandchild;